# Global Translation Matrix

Recommended initial locales:
- en — English
- hi — Hindi
- fr — French
- de — German
- es — Spanish
- pt-BR — Portuguese (Brazil)
- id — Indonesian
- ja — Japanese
- ko — Korean
- ar — Arabic (RTL)

Every user-visible string should come from a translation key.
Fallback: English.

Before release, verify:
- Home
- Money
- Paisa Len-Den
- Goals & Planning
- Bills & Loans
- Reports
- Settings
- Add/Edit/Delete confirmations
- Empty states
- Errors
- Notifications
- Consent/privacy text
