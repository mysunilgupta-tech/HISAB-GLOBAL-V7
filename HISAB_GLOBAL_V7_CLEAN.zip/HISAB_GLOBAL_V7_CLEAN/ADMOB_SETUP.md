# HISAB V2 — AdMob Setup

This ZIP contains the **source-side AdMob integration**, but it cannot contain your private AdMob Application ID / Ad Unit IDs.

## 1. Install the Capacitor AdMob plugin

The current HISAB project uses Capacitor 7, so install the Capacitor-7-compatible major:

```bash
npm install @capacitor-community/admob@7
npx cap sync
```

The plugin documentation states that Capacitor 7 projects should use `@capacitor-community/admob@7`.

## 2. Add the AdMob Application ID

In:

`android/app/src/main/AndroidManifest.xml`

inside `<application>` add:

```xml
<meta-data
    android:name="com.google.android.gms.ads.APPLICATION_ID"
    android:value="@string/admob_app_id" />
```

Then in:

`android/app/src/main/res/values/strings.xml`

add:

```xml
<string name="admob_app_id">YOUR_ADMOB_APP_ID</string>
```

Use the **AdMob App ID**, not a Banner Ad Unit ID.

## 3. Test first

The included `admob.js` uses Google's Android demo Banner/Interstitial IDs and `TEST_MODE = true`.

Do not click production ads during testing.

## 4. Before Play Store release

Create your own AdMob:
- App ID
- Banner Ad Unit ID
- Interstitial Ad Unit ID
- App Open Ad Unit ID (if you decide to use App Open)

Then replace the IDs in `admob.js` and set:

```js
const TEST_MODE = false;
```

## 5. HISAB placement

Current integration starts a bottom adaptive Banner after initialization.

Interstitial is intentionally rate-limited and should not be shown during:
- Add Income
- Add Expense
- Money Given
- Money Received
- Loan/EMI entry

Consent is requested before ads are loaded.

Reference:
https://github.com/capacitor-community/admob
