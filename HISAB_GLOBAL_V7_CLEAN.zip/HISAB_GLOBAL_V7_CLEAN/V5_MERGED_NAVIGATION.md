# HISAB V5 — Merged Navigation

Home options are grouped by purpose instead of showing separate cards for every feature.

- Money: Income, Expenses, Budget, Savings
- Paisa Len-Den: Given, Received, People, Due, History
- Goals & Planning: Budget, Savings Goals, Future Planning
- Bills & Loans: Bills, EMI, Loans, Reminders
- Reports: Summary, Categories, Export, Backup
- More: Currency, Backup, Privacy, Settings
- Business Khata remains a separate Business area.

Existing underlying screens and data functions are preserved; this update changes the home navigation presentation.
