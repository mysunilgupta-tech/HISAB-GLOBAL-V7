HISAB V4 — Complete update package

Added:
- Personal and Business mode separation for transactions, goals, budgets, bills and loans
- Home totals + current-month income/expense tracking
- Income/Expense filters
- Transaction edit/delete
- Paisa Len-Den edit, paid/pending, due/overdue display, search
- Goals add/withdraw savings
- Budget spent/remaining/over-budget display
- Loans & EMI counter
- Bills/reminders with overdue display
- Reports + category expense summary
- JSON backup/restore validation
- CSV transaction export
- Light/Dark theme preference
- English/Hindi preference toggle
- Existing AdMob-ready layer retained
- Existing no-login/local-first approach retained

Release note:
The native Capacitor AdMob plugin, Android App ID, production ad-unit IDs,
consent configuration, signing, and Play Store release configuration still
need to be completed in the Android project. Test ad IDs remain enabled.
