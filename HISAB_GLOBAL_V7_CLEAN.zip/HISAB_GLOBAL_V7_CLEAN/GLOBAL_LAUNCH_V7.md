# HISAB Global V7 — Global Launch Upgrade Pack

V7 preserves the V6 app structure and adds a launch-readiness configuration layer.

## Included
- Complete translation rollout checklist
- Locale/currency formatting requirements
- Region-aware settings checklist
- AdMob/consent production checklist
- Privacy and Data Safety checklist
- Backup/restore validation checklist
- Reminder/notification checklist
- Reports QA checklist
- Accessibility, RTL and responsive QA checklist
- APK/AAB release checklist

## Important
Real AdMob App ID/Ad Unit IDs, Privacy Policy URL, Play Console declarations,
and final translations must be supplied before production release.

Do not replace existing project files blindly. Integrate this package into the
existing Capacitor project after inspecting its current structure.
