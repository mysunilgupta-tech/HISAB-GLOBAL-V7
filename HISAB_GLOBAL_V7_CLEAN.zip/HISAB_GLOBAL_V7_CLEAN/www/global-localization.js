/* HISAB Global Localization V6 */
(function(){
  const KEY='hisab_global_locale_v6';
  const map={
    en:{name:'English',currency:'$',label:{'Money Manager':'Money Manager','Track • Plan • Grow':'Track • Plan • Grow','Welcome to HISAB':'Welcome to HISAB','Continue without Login':'Continue without Login','Welcome Back!':'Welcome Back!','Offline • Private':'Offline • Private','CHOOSE MODE':'CHOOSE MODE','Manage Your Money':'Manage Your Money','Personal':'Personal','Business':'Business','Money Overview':'Money Overview','Income':'Income','Expenses':'Expenses','Savings':'Savings','Balance':'Balance','MAIN SECTIONS':'MAIN SECTIONS','Everything in One Place':'Everything in One Place','Money':'Money','Paisa Len-Den':'Money Given / Received','Goals & Planning':'Goals & Planning','Bills & Loans':'Bills & Loans','Reports':'Reports','More':'More','Business Tools':'Business Tools','Business Khata':'Business Ledger','People':'People','Due Date':'Due Date','Reminder':'Reminder','Search':'Search','FAST ACTIONS':'FAST ACTIONS','Quick Add':'Quick Add','Given':'Given','Received':'Received','Personal':'Personal','Transactions':'Transactions','Income & Expenses':'Income & Expenses','Record every rupee':'Record every transaction','Add Transaction':'Add Transaction','Category':'Category','Note':'Note','Date':'Date','Save Transaction':'Save Transaction','Recent Transactions':'Recent Transactions','All':'All','Plan':'Plan','Budget & Goals':'Budget & Goals','Monthly Budget':'Monthly Budget','Monthly Limit ₹':'Monthly Limit $','Add Budget':'Add Budget','Future Goal':'Future Goal','Goal Name':'Goal Name','Target Amount ₹':'Target Amount $','Current Saving ₹':'Current Saving $','Deadline':'Deadline','Create Goal':'Create Goal','Loans & EMI':'Loans & EMI','Add Loan / EMI':'Add Loan / EMI','Loan Name':'Loan Name','Bank / Finance Company':'Bank / Finance Company','Loan Amount ₹':'Loan Amount $','Monthly EMI ₹':'Monthly EMI $','Tenure (months)':'Tenure (months)','Save Loan':'Save Loan','EMI Calculator':'EMI Calculator','Principal ₹':'Principal $','Annual Interest %':'Annual Interest %'}},
    hi:{name:'हिन्दी',currency:'₹',label:{}},
    fr:{name:'Français',currency:'€',label:{}},
    de:{name:'Deutsch',currency:'€',label:{}},
    es:{name:'Español',currency:'€',label:{}},
    pt:{name:'Português',currency:'R$',label:{}},
    id:{name:'Bahasa Indonesia',currency:'Rp',label:{}},
    ja:{name:'日本語',currency:'¥',label:{}},
    ko:{name:'한국어',currency:'₩',label:{}},
    ar:{name:'العربية',currency:'﷼',label:{}}
  };
  const translations={
    hi:{'Money Manager':'मनी मैनेजर','Track • Plan • Grow':'ट्रैक • प्लान • ग्रो','Welcome to HISAB':'HISAB में आपका स्वागत है','Continue without Login':'बिना लॉगिन जारी रखें','Welcome Back!':'वापसी पर स्वागत है!','Offline • Private':'ऑफलाइन • निजी','CHOOSE MODE':'मोड चुनें','Manage Your Money':'अपने पैसे को मैनेज करें','Personal':'पर्सनल','Business':'बिज़नेस','Money Overview':'मनी ओवरव्यू','Income':'आमदनी','Expenses':'खर्च','Savings':'बचत','Balance':'बैलेंस','MAIN SECTIONS':'मुख्य सेक्शन','Everything in One Place':'सब कुछ एक जगह','Money':'पैसा','Paisa Len-Den':'पैसा लेन-देन','Goals & Planning':'लक्ष्य और योजना','Bills & Loans':'बिल और लोन','Reports':'रिपोर्ट्स','More':'और','Business Tools':'बिज़नेस टूल्स','Business Khata':'बिज़नेस खाता','People':'लोग','Due Date':'देय तारीख','Reminder':'रिमाइंडर','Search':'सर्च','FAST ACTIONS':'क्विक एक्शन','Quick Add':'क्विक ऐड','Given':'दिया','Received':'लिया','Income & Expenses':'आमदनी और खर्च','Record every rupee':'हर लेन-देन दर्ज करें','Add Transaction':'लेन-देन जोड़ें','Category':'कैटेगरी','Note':'नोट','Date':'तारीख','Save Transaction':'लेन-देन सेव करें','Recent Transactions':'हाल के लेन-देन','All':'सभी','Budget & Goals':'बजट और लक्ष्य','Monthly Budget':'मासिक बजट','Monthly Limit ₹':'मासिक सीमा ₹','Add Budget':'बजट जोड़ें','Future Goal':'भविष्य का लक्ष्य','Goal Name':'लक्ष्य का नाम','Target Amount ₹':'लक्ष्य राशि ₹','Current Saving ₹':'वर्तमान बचत ₹','Deadline':'अंतिम तारीख','Create Goal':'लक्ष्य बनाएं','Loans & EMI':'लोन और EMI','Add Loan / EMI':'लोन / EMI जोड़ें','Loan Name':'लोन का नाम','Bank / Finance Company':'बैंक / फाइनेंस कंपनी','Loan Amount ₹':'लोन राशि ₹','Monthly EMI ₹':'मासिक EMI ₹','Tenure (months)':'अवधि (महीने)','Save Loan':'लोन सेव करें','EMI Calculator':'EMI कैलकुलेटर','Principal ₹':'मूल राशि ₹','Annual Interest %':'वार्षिक ब्याज %'},
    fr:{'Money Manager':'Gestionnaire d’argent','Personal':'Personnel','Business':'Entreprise','Money Overview':'Vue d’ensemble','Income':'Revenus','Expenses':'Dépenses','Savings':'Épargne','Balance':'Solde','Money':'Argent','Paisa Len-Den':'Argent donné / reçu','Goals & Planning':'Objectifs et planification','Bills & Loans':'Factures et prêts','Reports':'Rapports','More':'Plus','People':'Personnes','Due Date':'Date d’échéance','Reminder':'Rappel','Search':'Rechercher','Quick Add':'Ajout rapide'},
    de:{'Money Manager':'Geldverwaltung','Personal':'Privat','Business':'Geschäft','Money Overview':'Geldübersicht','Income':'Einnahmen','Expenses':'Ausgaben','Savings':'Ersparnisse','Balance':'Saldo','Money':'Geld','Goals & Planning':'Ziele & Planung','Bills & Loans':'Rechnungen & Kredite','Reports':'Berichte','More':'Mehr','People':'Personen','Due Date':'Fälligkeitsdatum','Reminder':'Erinnerung','Search':'Suchen'},
    es:{'Money Manager':'Gestor de dinero','Personal':'Personal','Business':'Negocio','Money Overview':'Resumen del dinero','Income':'Ingresos','Expenses':'Gastos','Savings':'Ahorros','Balance':'Saldo','Money':'Dinero','Goals & Planning':'Metas y planificación','Bills & Loans':'Facturas y préstamos','Reports':'Informes','More':'Más','People':'Personas','Due Date':'Fecha de vencimiento','Reminder':'Recordatorio','Search':'Buscar'},
    pt:{'Money Manager':'Gestor financeiro','Personal':'Pessoal','Business':'Negócio','Money Overview':'Visão geral do dinheiro','Income':'Receitas','Expenses':'Despesas','Savings':'Poupança','Balance':'Saldo','Money':'Dinheiro','Goals & Planning':'Metas e planejamento','Bills & Loans':'Contas e empréstimos','Reports':'Relatórios','More':'Mais','People':'Pessoas','Due Date':'Data de vencimento','Reminder':'Lembrete','Search':'Pesquisar'},
    id:{'Money Manager':'Pengelola Keuangan','Personal':'Pribadi','Business':'Bisnis','Money Overview':'Ringkasan Keuangan','Income':'Pemasukan','Expenses':'Pengeluaran','Savings':'Tabungan','Balance':'Saldo','Money':'Uang','Goals & Planning':'Tujuan & Perencanaan','Bills & Loans':'Tagihan & Pinjaman','Reports':'Laporan','More':'Lainnya','People':'Orang','Due Date':'Jatuh Tempo','Reminder':'Pengingat','Search':'Cari'},
    ja:{'Money Manager':'マネーマネージャー','Personal':'個人','Business':'ビジネス','Money Overview':'お金の概要','Income':'収入','Expenses':'支出','Savings':'貯金','Balance':'残高','Money':'お金','Goals & Planning':'目標と計画','Bills & Loans':'請求・ローン','Reports':'レポート','More':'その他','People':'人','Due Date':'支払期日','Reminder':'リマインダー','Search':'検索'},
    ko:{'Money Manager':'머니 매니저','Personal':'개인','Business':'비즈니스','Money Overview':'자금 개요','Income':'수입','Expenses':'지출','Savings':'저축','Balance':'잔액','Money':'자금','Goals & Planning':'목표 및 계획','Bills & Loans':'청구서 및 대출','Reports':'보고서','More':'더보기','People':'사람','Due Date':'기한','Reminder':'알림','Search':'검색'},
    ar:{'Money Manager':'مدير الأموال','Personal':'شخصي','Business':'الأعمال','Money Overview':'نظرة عامة على الأموال','Income':'الدخل','Expenses':'المصروفات','Savings':'المدخرات','Balance':'الرصيد','Money':'المال','Goals & Planning':'الأهداف والتخطيط','Bills & Loans':'الفواتير والقروض','Reports':'التقارير','More':'المزيد','People':'الأشخاص','Due Date':'تاريخ الاستحقاق','Reminder':'تذكير','Search':'بحث'}
  };
  Object.keys(translations).forEach(k=>Object.assign(map[k].label,translations[k]));
  function detect(){
    const saved=localStorage.getItem(KEY);
    if(saved) try{return JSON.parse(saved)}catch(e){}
    const lang=(navigator.language||'en').toLowerCase().split('-')[0];
    return {lang:map[lang]?lang:'en', currency:map[lang]?.currency||'$', auto:true};
  }
  let state=detect();
  function apply(){
    const l=state.lang, dict=map[l]?.label||map.en.label;
    document.documentElement.lang=l;
    document.documentElement.dir=l==='ar'?'rtl':'ltr';
    document.querySelectorAll('input[placeholder],textarea[placeholder]').forEach(el=>{
      if(dict[el.placeholder]) el.placeholder=dict[el.placeholder];
    });
    const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
    const nodes=[]; while(walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(n=>{
      const t=n.nodeValue.trim(); if(!t || !dict[t]) return;
      n.nodeValue=n.nodeValue.replace(t,dict[t]);
    });
    document.querySelectorAll('[data-currency]').forEach(el=>el.textContent=state.currency);
    window.HISAB_LOCALE=state;
  }
  function setLanguage(lang,currency){
    if(!map[lang]) lang='en';
    state={lang,currency:currency||map[lang].currency,auto:false};
    localStorage.setItem(KEY,JSON.stringify(state)); apply();
    return state;
  }
  window.HISABGlobal={state,getLanguages:()=>Object.entries(map).map(([code,x])=>({code,name:x.name,currency:x.currency})),setLanguage,apply};
  window.HISABCurrencySymbol=()=>state.currency;
  window.HISABFormatMoney=(n)=>{
    try{return new Intl.NumberFormat(state.lang+'-'+(state.lang==='en'?'US':state.lang==='hi'?'IN':'ZZ'),{style:'currency',currency:({hi:'INR',en:'USD',fr:'EUR',de:'EUR',es:'EUR',pt:'BRL',id:'IDR',ja:'JPY',ko:'KRW',ar:'SAR'})[state.lang]||'USD',maximumFractionDigits:2}).format(Number(n)||0)}catch(e){return state.currency+(Number(n)||0)}
  };
  document.addEventListener('DOMContentLoaded',apply);
})();