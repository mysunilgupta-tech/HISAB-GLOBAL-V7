
import { initHISABAdMob } from './admob.js';

const KEY='hisab_money_manager_v4';
const defaults={
  mode:'Personal',currency:'₹',language:'English',theme:'light',
  transactions:[],lendings:[],goals:[],budgets:[],bills:[],loans:[],
  recurring:[]
};
let data=load(), txType='income', txFilter='all';

function cloneDefaults(){return JSON.parse(JSON.stringify(defaults))}
function load(){
  try{
    const x=JSON.parse(localStorage.getItem(KEY)||'{}');
    return {...cloneDefaults(),...x};
  }catch(e){return cloneDefaults()}
}
function save(){localStorage.setItem(KEY,JSON.stringify(data));renderAll()}
function money(n){return `${data.currency}${Number(n||0).toLocaleString('en-IN',{maximumFractionDigits:2})}`}
function today(){return new Date().toISOString().slice(0,10)}
function uid(){return Date.now().toString(36)+Math.random().toString(36).slice(2,8)}
function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function modeTx(){return data.transactions.filter(x=>(x.mode||'Personal')===data.mode)}
function modeLending(){return data.lendings.filter(x=>(x.mode||'Personal')===data.mode)}
function monthKey(d=today()){return String(d).slice(0,7)}
function totals(){
  const tx=modeTx(), ld=modeLending();
  const income=tx.filter(x=>x.type==='income').reduce((s,x)=>s+Number(x.amount||0),0);
  const expense=tx.filter(x=>x.type==='expense').reduce((s,x)=>s+Number(x.amount||0),0);
  const given=ld.filter(x=>x.type==='given'&&x.status!=='paid').reduce((s,x)=>s+Number(x.amount||0),0);
  const received=ld.filter(x=>x.type==='received'&&x.status!=='paid').reduce((s,x)=>s+Number(x.amount||0),0);
  const month=tx.filter(x=>String(x.date).slice(0,7)===monthKey());
  const mi=month.filter(x=>x.type==='income').reduce((s,x)=>s+Number(x.amount||0),0);
  const me=month.filter(x=>x.type==='expense').reduce((s,x)=>s+Number(x.amount||0),0);
  return {income,expense,balance:income-expense,given,received,net:given-received,monthIncome:mi,monthExpense:me,monthBalance:mi-me};
}
function enterGuestMode(){
  localStorage.setItem('hisab_guest_mode','true');
  document.getElementById('guestGate').classList.add('hidden');
  document.getElementById('appShell').classList.remove('hidden');
  show('home'); toast('Welcome to HISAB');
}
function restore(){
  if(localStorage.getItem('hisab_guest_mode')==='true'){
    document.getElementById('guestGate').classList.add('hidden');
    document.getElementById('appShell').classList.remove('hidden');
  }
}
function show(id){
  document.querySelectorAll('.screen').forEach(x=>x.classList.add('hidden'));
  const el=document.getElementById(id); if(el)el.classList.remove('hidden');
  document.querySelectorAll('.bottom-nav button[data-screen]').forEach(b=>b.classList.toggle('active',b.dataset.screen===id));
  window.scrollTo({top:0,behavior:'smooth'});
  renderAll();
}
function setMode(m){data.mode=m;save();toast(`${m} mode selected`)}
function toggleCurrency(){data.currency=data.currency==='₹'?'$':'₹';save();toast(`Currency: ${data.currency}`)}
function addTransaction(type,amount,note='',date=today(),category='Other',recurring=false){
  amount=Number(amount);
  if(amount<=0)return toast('Enter a valid amount');
  data.transactions.unshift({id:uid(),type,amount,note,date,category,mode:data.mode,recurring});
  save(); toast(type==='income'?'Income added':'Expense added');
}
function setTxType(t){
  txType=t;
  document.getElementById('txIncomeTab')?.classList.toggle('active',t==='income');
  document.getElementById('txExpenseTab')?.classList.toggle('active',t==='expense');
}
function saveTxForm(e){
  e.preventDefault();
  addTransaction(txType,document.getElementById('txAmount').value,
    document.getElementById('txNote').value,document.getElementById('txDate').value||today(),
    document.getElementById('txCat').value||'Other');
  e.target.reset(); document.getElementById('txDate').value=today();
}
function editTransaction(id){
  const x=data.transactions.find(a=>a.id===id); if(!x)return;
  const amount=prompt('Amount',x.amount); if(amount===null)return;
  const note=prompt('Note',x.note||''); if(note===null)return;
  const cat=prompt('Category',x.category||'Other'); if(cat===null)return;
  x.amount=Number(amount)||x.amount; x.note=note; x.category=cat; save(); toast('Transaction updated');
}
function deleteTransaction(id){
  if(!confirm('Delete this transaction?'))return;
  data.transactions=data.transactions.filter(x=>x.id!==id);save();toast('Transaction deleted');
}
function openLendingForm(type){
  const c=document.getElementById('lendingForm');c.classList.remove('hidden');
  c.innerHTML=`<div class="form-title">${type==='given'?'↗ Money Given':'↙ Money Received'}</div>
  <form onsubmit="saveLendingForm(event,'${type}')">
  <label>Person Name<input id="lendPerson" required placeholder="Person name"></label>
  <label>Amount<input id="lendAmount" type="number" min="1" required placeholder="5000"></label>
  <label>Due Date<input id="lendDue" type="date"></label>
  <label>Note<input id="lendNote" placeholder="Optional"></label>
  <div class="action-row"><button type="submit" class="btn btn-primary">Save</button>
  <button type="button" class="btn btn-secondary" onclick="document.getElementById('lendingForm').classList.add('hidden')">Cancel</button></div></form>`;
}
function saveLendingForm(e,type){
  e.preventDefault();
  const person=document.getElementById('lendPerson').value.trim(),amount=Number(document.getElementById('lendAmount').value);
  if(!person||amount<=0)return toast('Enter valid details');
  data.lendings.unshift({id:uid(),type,person,amount,dueDate:document.getElementById('lendDue').value,
    note:document.getElementById('lendNote').value,date:today(),status:'pending',mode:data.mode});
  save();document.getElementById('lendingForm').classList.add('hidden');toast('Entry saved');
}
function editLending(id){
  const x=data.lendings.find(a=>a.id===id);if(!x)return;
  const p=prompt('Person name',x.person);if(p===null)return;
  const a=prompt('Amount',x.amount);if(a===null)return;
  const d=prompt('Due date YYYY-MM-DD',x.dueDate||'');if(d===null)return;
  x.person=p.trim()||x.person;x.amount=Number(a)||x.amount;x.dueDate=d;save();toast('Entry updated');
}
function markLendingPaid(id){let x=data.lendings.find(a=>a.id===id);if(x){x.status=x.status==='paid'?'pending':'paid';save();toast(x.status==='paid'?'Marked paid':'Marked pending')}}
function deleteLending(id){if(!confirm('Delete this entry?'))return;data.lendings=data.lendings.filter(x=>x.id!==id);save()}
function quickLending(type){show('personal');setTimeout(()=>openLendingForm(type),80)}
function openBusinessForm(){
  const c=document.getElementById('businessForm');c.classList.remove('hidden');
  c.innerHTML='<div class="form-title">＋ Add Customer</div><form onsubmit="saveBusiness(event)"><label>Customer Name<input id="bizPerson" required placeholder="Customer name"></label><label>Amount Due<input id="bizAmount" type="number" min="0" value="0"></label><label>Note<input id="bizNote" placeholder="Optional"></label><div class="action-row"><button class="btn btn-primary">Save Customer</button><button type="button" class="btn btn-secondary" onclick="document.getElementById(\'businessForm\').classList.add(\'hidden\')">Cancel</button></div></form>';
}
function saveBusiness(e){
  e.preventDefault();
  data.lendings.unshift({id:uid(),type:'given',person:document.getElementById('bizPerson').value.trim(),
    amount:Number(document.getElementById('bizAmount').value||0),dueDate:'',note:document.getElementById('bizNote').value,
    date:today(),status:'pending',mode:'Business'});
  data.mode='Business';save();document.getElementById('businessForm').classList.add('hidden');toast('Customer added');
}
function quickTransaction(type){show('transactions');setTimeout(()=>setTxType(type),80)}
function saveBudgetForm(e){
  e.preventDefault();const amount=Number(document.getElementById('budgetAmount').value);
  if(amount<=0)return toast('Enter a valid budget');
  data.budgets.unshift({id:uid(),category:document.getElementById('budgetCategory').value.trim()||'Other',amount,month:monthKey()});
  save();e.target.reset();toast('Budget added');
}
function deleteBudget(id){data.budgets=data.budgets.filter(x=>x.id!==id);save()}
function saveGoalForm(e){
  e.preventDefault();const target=Number(document.getElementById('gTarget').value);
  if(target<=0)return toast('Enter a valid target');
  data.goals.unshift({id:uid(),name:document.getElementById('gName').value.trim(),target,
    saved:Number(document.getElementById('gCurrent').value||0),deadline:document.getElementById('gDeadline').value,mode:data.mode});
  save();e.target.reset();toast('Goal created');
}
function addGoalSaving(id){
  const a=Number(prompt('Add saving amount', '1000'));if(a>0){const g=data.goals.find(x=>x.id===id);if(g){g.saved=Math.min(g.target,g.saved+a);save();toast('Goal updated')}}
}
function withdrawGoalSaving(id){
  const a=Number(prompt('Withdraw amount','500'));if(a>0){const g=data.goals.find(x=>x.id===id);if(g){g.saved=Math.max(0,g.saved-a);save();toast('Goal updated')}}
}
function deleteGoal(id){if(!confirm('Delete this goal?'))return;data.goals=data.goals.filter(x=>x.id!==id);save()}
function saveLoanForm(e){
  e.preventDefault();const amount=Number(document.getElementById('loanAmount').value),emi=Number(document.getElementById('loanEmi').value);
  if(amount<=0||emi<=0)return toast('Enter valid loan details');
  data.loans.unshift({id:uid(),name:document.getElementById('loanName').value,lender:document.getElementById('loanLender').value,
    amount,emi,dueDate:document.getElementById('loanDue').value,tenure:document.getElementById('loanTenure').value,paidEmis:0,mode:data.mode});
  save();e.target.reset();toast('Loan saved');
}
function payEMI(id){const x=data.loans.find(a=>a.id===id);if(x){x.paidEmis=(x.paidEmis||0)+1;save();toast('EMI marked paid')}}
function deleteLoan(id){if(!confirm('Delete this loan?'))return;data.loans=data.loans.filter(x=>x.id!==id);save()}
function calculateEMIForm(e){
  e.preventDefault();const p=Number(document.getElementById('calcLoan').value),r=Number(document.getElementById('calcRate').value)/1200,n=Number(document.getElementById('calcTenure').value);
  if(p<=0||n<=0)return toast('Enter calculator values');
  const emi=r?p*r*Math.pow(1+r,n)/(Math.pow(1+r,n)-1):p/n;
  document.getElementById('emiResult').innerHTML=`<div class="list-item"><b>Estimated EMI: ${money(emi)}</b><small>Total payment: ${money(emi*n)} • Interest: ${money(emi*n-p)}</small></div>`;
}
function saveReminderForm(e){
  e.preventDefault();data.bills.unshift({id:uid(),name:document.getElementById('remName').value,type:document.getElementById('remType').value,
    dueDate:document.getElementById('remDate').value,amount:Number(document.getElementById('remAmount').value||0),
    note:document.getElementById('remNote').value,status:'pending',mode:data.mode});
  save();e.target.reset();toast('Reminder saved');
}
function markBillPaid(id){const x=data.bills.find(a=>a.id===id);if(x){x.status=x.status==='paid'?'pending':'paid';save()}}
function deleteBill(id){if(!confirm('Delete this reminder?'))return;data.bills=data.bills.filter(x=>x.id!==id);save()}
function searchHisab(q){renderLendings(q)}
function isOverdue(d){return d && d<today()}
function renderLendings(q=''){
  const c=document.getElementById('lendingList');if(!c)return;
  let list=modeLending().filter(x=>(`${x.person} ${x.note} ${x.type}`).toLowerCase().includes(String(q).toLowerCase()));
  c.innerHTML=list.length?list.map(x=>`<div class="list-item"><div class="list-top"><div><b>${esc(x.person)}</b><small>${esc(x.type)} • ${esc(x.date)}${x.dueDate?' • Due '+esc(x.dueDate):''}${isOverdue(x.dueDate)&&x.status!=='paid'?' • OVERDUE':''}</small></div><b class="${x.type==='given'?'amount-given':'amount-received'}">${money(x.amount)}</b></div>${x.note?`<small>${esc(x.note)}</small>`:''}<div class="item-actions"><button onclick="markLendingPaid('${x.id}')">${x.status==='paid'?'Mark Pending':'Mark Paid'}</button><button onclick="editLending('${x.id}')">Edit</button><button onclick="deleteLending('${x.id}')">Delete</button></div></div>`).join(''):'<div class="empty-state">No Paisa Len-Den records yet</div>';
}
function renderBusiness(){
  const c=document.getElementById('businessList');if(!c)return;
  const list=data.lendings.filter(x=>x.mode==='Business');
  c.innerHTML=list.length?list.map(x=>`<div class="list-item"><div class="list-top"><div><b>${esc(x.person)}</b><small>Business customer • ${esc(x.date)}</small></div><b class="amount-given">${money(x.amount)}</b></div><small>${esc(x.note||'Outstanding customer balance')}</small><div class="item-actions"><button onclick="markLendingPaid('${x.id}')">${x.status==='paid'?'Pending':'Received'}</button><button onclick="editLending('${x.id}')">Edit</button><button onclick="deleteLending('${x.id}')">Delete</button></div></div>`).join(''):'<div class="empty-state">No customers added yet</div>';
  document.getElementById('businessPeople').textContent=list.length;
  document.getElementById('businessReceivable').textContent=money(list.filter(x=>x.status!=='paid').reduce((s,x)=>s+x.amount,0));
  document.getElementById('businessReceived').textContent=money(list.filter(x=>x.status==='paid').reduce((s,x)=>s+x.amount,0));
}
function renderTransactions(){
  const c=document.getElementById('transactionList');if(!c)return;
  let list=modeTx();
  if(txFilter!=='all')list=list.filter(x=>x.type===txFilter);
  c.innerHTML=list.length?list.map(x=>`<div class="list-item"><div class="list-top"><div><b>${esc(x.category||x.type)}</b><small>${esc(x.date)} • ${esc(x.mode)}${x.recurring?' • Recurring':''}</small></div><b class="${x.type==='income'?'amount-income':'amount-given'}">${x.type==='income'?'+':'−'}${money(x.amount)}</b></div>${x.note?`<small>${esc(x.note)}</small>`:''}<div class="item-actions"><button onclick="editTransaction('${x.id}')">Edit</button><button onclick="deleteTransaction('${x.id}')">Delete</button></div></div>`).join(''):'<div class="empty-state">No transactions yet</div>';
}
function renderBudgets(){
  const c=document.getElementById('budgetList');if(!c)return;
  const list=data.budgets.filter(b=>(b.mode||data.mode)===data.mode);
  c.innerHTML=list.length?list.map(b=>{
    const spent=modeTx().filter(x=>x.type==='expense'&&x.category===b.category&&x.date.slice(0,7)===b.month).reduce((s,x)=>s+x.amount,0);
    const pct=Math.min(100,b.amount?spent/b.amount*100:0);
    return `<div class="list-item"><div class="list-top"><b>${esc(b.category)}</b><b>${money(b.amount)}</b></div><div class="progress"><i style="width:${pct}%"></i></div><small>Spent ${money(spent)} • Remaining ${money(Math.max(0,b.amount-spent))}${spent>b.amount?' • Over budget':''}</small><div class="item-actions"><button onclick="deleteBudget('${b.id}')">Delete</button></div></div>`
  }).join(''):'<div class="empty-state">No budgets yet</div>';
}
function renderGoals(){
  const c=document.getElementById('goalList');if(!c)return;
  const list=data.goals.filter(g=>(g.mode||data.mode)===data.mode);
  c.innerHTML=list.length?list.map(g=>{
    const pct=Math.min(100,g.target?g.saved/g.target*100:0);
    return `<div class="list-item"><div class="list-top"><b>🎯 ${esc(g.name)}</b><b>${Math.round(pct)}%</b></div><div class="progress"><i style="width:${pct}%"></i></div><small>${money(g.saved)} saved of ${money(g.target)}${g.deadline?' • Deadline '+esc(g.deadline):''}</small><div class="item-actions"><button onclick="addGoalSaving('${g.id}')">＋ Add Saving</button><button onclick="withdrawGoalSaving('${g.id}')">− Withdraw</button><button onclick="deleteGoal('${g.id}')">Delete</button></div></div>`
  }).join(''):'<div class="empty-state">No goals yet</div>';
}
function renderLoans(){
  const c=document.getElementById('loanList');if(!c)return;
  const list=data.loans.filter(x=>(x.mode||data.mode)===data.mode);
  c.innerHTML=list.length?list.map(l=>`<div class="list-item"><div class="list-top"><div><b>${esc(l.name)}</b><small>${esc(l.lender||'Bank / Finance')} • EMI ${money(l.emi)}</small></div><b>${money(l.amount)}</b></div><small>Paid EMIs: ${l.paidEmis||0}${l.tenure?' / '+esc(l.tenure):''}${l.dueDate?' • Due '+esc(l.dueDate):''}</small><div class="item-actions"><button onclick="payEMI('${l.id}')">Pay EMI</button><button onclick="deleteLoan('${l.id}')">Delete</button></div></div>`).join(''):'<div class="empty-state">No loans / EMI added</div>';
}
function renderBills(){
  const c=document.getElementById('remList');if(!c)return;
  const list=data.bills.filter(x=>(x.mode||data.mode)===data.mode);
  c.innerHTML=list.length?list.map(b=>`<div class="list-item"><div class="list-top"><div><b>🔔 ${esc(b.name)}</b><small>${esc(b.type)} • Due ${esc(b.dueDate)}${isOverdue(b.dueDate)&&b.status!=='paid'?' • OVERDUE':''}</small></div><b>${money(b.amount)}</b></div>${b.note?`<small>${esc(b.note)}</small>`:''}<div class="item-actions"><button onclick="markBillPaid('${b.id}')">${b.status==='paid'?'Mark Pending':'Mark Paid'}</button><button onclick="deleteBill('${b.id}')">Delete</button></div></div>`).join(''):'<div class="empty-state">No reminders yet</div>';
}
function renderReports(){
  const t=totals();
  for(const [id,val] of Object.entries({rIncome:money(t.income),rExpense:money(t.expense),rSaving:money(t.balance),reportIncome:money(t.income),reportExpense:money(t.expense),reportBalance:money(t.balance)})){const e=document.getElementById(id);if(e)e.textContent=val}
  const rc=document.getElementById('reportCount');if(rc)rc.textContent=modeTx().length;
  const cs=document.getElementById('catSummary');
  if(cs){
    const map={};modeTx().filter(x=>x.type==='expense').forEach(x=>map[x.category]=(map[x.category]||0)+Number(x.amount));
    cs.innerHTML=Object.keys(map).length?Object.entries(map).sort((a,b)=>b[1]-a[1]).map(([k,v])=>`<div class="list-top" style="padding:8px 0;border-bottom:1px solid var(--border)"><span>${esc(k)}</span><b>${money(v)}</b></div>`).join(''):'<div class="empty-state">Add expenses to see category summary</div>';
  }
  const rMonth=document.getElementById('reportMonth');if(rMonth)rMonth.textContent=`This month: ${money(t.monthIncome)} income • ${money(t.monthExpense)} expense`;
}
function renderDashboard(){
  const t=totals();
  const vals={homeIncome:money(t.income),homeExpense:money(t.expense),homeSaving:money(Math.max(0,t.balance)),
    homeBalance:money(t.balance),homeGiven:money(t.given),homeReceived:money(t.received),homeNet:money(t.net),
    ledgerGiven:money(t.given),ledgerReceived:money(t.received),ledgerNet:money(t.net)};
  for(const [id,val] of Object.entries(vals)){const e=document.getElementById(id);if(e)e.textContent=val}
}
function renderAll(){
  renderDashboard();renderTransactions();renderLendings(document.getElementById('hisabSearch')?.value||'');
  renderBusiness();renderBudgets();renderGoals();renderLoans();renderBills();renderReports();
  const d=document.getElementById('txDate');if(d&&!d.value)d.value=today();
  applyPreferences();
}
function exportBackup(){
  const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),a=document.createElement('a');
  a.href=URL.createObjectURL(blob);a.download=`HISAB-Backup-${today()}.json`;a.click();URL.revokeObjectURL(a.href);toast('Backup exported');
}
function exportCSV(){
  const rows=[['Date','Type','Category','Amount','Note','Mode'],...modeTx().map(x=>[x.date,x.type,x.category,x.amount,x.note||'',x.mode])];
  const csv=rows.map(r=>r.map(v=>`"${String(v).replaceAll('"','""')}"`).join(',')).join('\n');
  const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));a.download=`HISAB-${data.mode}-${today()}.csv`;a.click();URL.revokeObjectURL(a.href);toast('CSV exported');
}
function importBackup(file){
  if(!file)return;
  const r=new FileReader();r.onload=e=>{
    try{
      const x=JSON.parse(e.target.result);
      if(!x||!Array.isArray(x.transactions)||!Array.isArray(x.lendings))throw Error();
      data={...cloneDefaults(),...x};save();toast('Backup restored');
    }catch(err){toast('Invalid HISAB backup')}
  };r.readAsText(file);
}
function clearData(){
  if(confirm('Delete all HISAB data from this device?')){
    localStorage.removeItem(KEY);data=cloneDefaults();save();toast('All data cleared');
  }
}
function toggleTheme(){data.theme=data.theme==='dark'?'light':'dark';save();toast(`${data.theme} mode`)}
function toggleLanguage(){data.language=data.language==='English'?'Hindi':'English';save();toast(`Language: ${data.language}`)}
function applyPreferences(){document.body.dataset.theme=data.theme||'light'}
function filterTransactions(t){txFilter=t;renderTransactions()}
function toast(msg){
  let t=document.getElementById('hisabToast');
  if(!t){t=document.createElement('div');t.id='hisabToast';Object.assign(t.style,{position:'fixed',left:'50%',bottom:'78px',transform:'translateX(-50%)',padding:'11px 15px',borderRadius:'12px',background:'#14202a',color:'#fff',zIndex:9999,fontSize:'12px',boxShadow:'0 8px 25px rgba(0,0,0,.18)',maxWidth:'90%',textAlign:'center'});document.body.appendChild(t)}
  t.textContent=msg;t.style.display='block';clearTimeout(window.__toast);window.__toast=setTimeout(()=>t.style.display='none',2200);
}

Object.assign(window,{enterGuestMode,show,setMode,toggleCurrency,quickTransaction,quickLending,openLendingForm,saveLendingForm,
markLendingPaid,deleteLending,editLending,openBusinessForm,saveBusiness,setTxType,saveTxForm,deleteTransaction,editTransaction,
saveBudgetForm,deleteBudget,saveGoalForm,addGoalSaving,withdrawGoalSaving,deleteGoal,saveLoanForm,payEMI,deleteLoan,calculateEMIForm,
saveReminderForm,markBillPaid,deleteBill,searchHisab,exportBackup,exportCSV,importBackup,clearData,toggleTheme,toggleLanguage,filterTransactions});

document.addEventListener('DOMContentLoaded',async()=>{
  restore();renderAll();
  if(localStorage.getItem('hisab_guest_mode')==='true')show('home');
  try{await initHISABAdMob()}catch(err){console.warn('HISAB AdMob not available yet:',err)}
});
