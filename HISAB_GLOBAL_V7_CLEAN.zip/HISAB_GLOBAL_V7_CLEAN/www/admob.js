/*
 * HISAB AdMob integration
 * Uses @capacitor-community/admob.
 *
 * IMPORTANT:
 * 1) During development, keep TEST_MODE = true.
 * 2) Before release, replace the production ad unit IDs with your own AdMob IDs.
 * 3) The Android AdMob APPLICATION_ID belongs in AndroidManifest.xml, not here.
 */
import { Capacitor } from '@capacitor/core';
import {
  AdMob,
  AdmobConsentStatus,
  BannerAdSize,
  BannerAdPosition
} from '@capacitor-community/admob';

const TEST_MODE = true;

const IDS = {
  android: {
    banner: 'ca-app-pub-3940256099942544/6300978111',
    interstitial: 'ca-app-pub-3940256099942544/1033173712',
    appOpen: 'ca-app-pub-3940256099942544/9257395921'
  },
  ios: {
    banner: 'ca-app-pub-3940256099942544/2934735716',
    interstitial: 'ca-app-pub-3940256099942544/4411468910',
    appOpen: 'ca-app-pub-3940256099942544/5575463029'
  }
};

let initialized = false;
let consentReady = false;
let lastInterstitialAt = 0;

function platformIds() {
  return Capacitor.getPlatform() === 'ios' ? IDS.ios : IDS.android;
}

export async function initHISABAdMob() {
  if (Capacitor.getPlatform() === 'web' || initialized) return false;

  await AdMob.initialize();

  let consent = await AdMob.requestConsentInfo();
  if (consent.isConsentFormAvailable &&
      consent.status === AdmobConsentStatus.REQUIRED) {
    consent = await AdMob.showConsentForm();
  }

  consentReady = !!consent.canRequestAds;
  initialized = true;

  if (consentReady) {
    await showHISABBanner();
  }
  return consentReady;
}

export async function showHISABBanner() {
  if (!initialized || !consentReady) return;
  const ids = platformIds();

  await AdMob.showBanner({
    adId: ids.banner,
    adSize: BannerAdSize.ADAPTIVE_BANNER,
    position: BannerAdPosition.BOTTOM_CENTER,
    margin: 0,
    isTesting: TEST_MODE
  });
}

export async function hideHISABBanner() {
  if (Capacitor.getPlatform() === 'web') return;
  try { await AdMob.hideBanner(); } catch (_) {}
}

export async function showHISABInterstitial() {
  if (!initialized || !consentReady) return false;

  // Avoid interrupting frequent money-entry actions.
  const now = Date.now();
  if (now - lastInterstitialAt < 180000) return false;

  const ids = platformIds();
  await AdMob.prepareInterstitial({
    adId: ids.interstitial,
    isTesting: TEST_MODE
  });
  await AdMob.showInterstitial();
  lastInterstitialAt = now;
  return true;
}
