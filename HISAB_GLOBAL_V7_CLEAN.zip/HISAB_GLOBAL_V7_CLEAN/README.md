# HISAB Global V7 — Clean Android Base

Clean-start Android-ready base for HISAB Money Manager.

## Included
- No-login / offline local-first app
- Personal and Business modes
- Income / Expense
- Paisa Len-Den: Given / Received
- Goals and savings
- Budget
- Bills / reminders
- Loans / EMI and calculator
- Reports
- Backup / restore / CSV export
- Global localization and currency layer
- Arabic RTL foundation
- AdMob integration using test ad IDs for development
- Capacitor 7 Android build setup

## Build
```bash
npm install
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```

Production AdMob IDs, privacy policy, consent configuration, and signed AAB setup are still required before Play Store release.
