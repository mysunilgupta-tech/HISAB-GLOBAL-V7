# HISAB V7 Release QA

## Core
[ ] Guest/no-login flow
[ ] Personal/Business switching
[ ] Add/edit/delete transactions
[ ] Given/Received ledger
[ ] Goals
[ ] Budget
[ ] Bills
[ ] Loans/EMI
[ ] Reports

## Data
[ ] Local persistence
[ ] Backup export
[ ] Restore validation
[ ] CSV export

## Global
[ ] Device language detection
[ ] Manual language override
[ ] Currency override
[ ] Local number/date formatting
[ ] Arabic RTL
[ ] Large text/accessibility
[ ] Small/large Android screens

## Ads
[ ] Test ads during development
[ ] Production App ID configured
[ ] Production Ad Unit IDs configured
[ ] Consent flow tested
[ ] No disruptive ads during money entry
[ ] AdMob policy review completed

## Release
[ ] Privacy Policy
[ ] Data Safety form
[ ] App icon
[ ] Screenshots
[ ] Signed AAB
[ ] Internal/closed testing
[ ] Crash-free smoke test
