HISAB Image-Match V3

This package keeps the existing functional app.js + AdMob layer and refreshes the HTML/CSS presentation to closely follow the supplied HISAB concept: white mobile UI, navy branding, green Personal state, Personal/Business mode cards, Money Overview, 8 tool cards, Paisa Len-Den, Goals, Bills, Reports, and bottom navigation.

Important: this is source-ready for the existing Capacitor/GitHub project. The Android AdMob native plugin and real production AdMob IDs still need to be configured in the Capacitor Android project before Play Store release.
