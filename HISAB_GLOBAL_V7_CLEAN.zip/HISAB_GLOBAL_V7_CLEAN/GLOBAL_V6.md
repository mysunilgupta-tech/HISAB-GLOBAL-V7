# HISAB Global V6
- Automatic device-language detection with English fallback.
- Supported starter locales: English, Hindi, French, German, Spanish, Portuguese, Indonesian, Japanese, Korean, Arabic.
- Locale-aware document direction for Arabic.
- Default currency mapping with manual override API: `HISABGlobal.setLanguage(code, currency)`.
- Uses browser Intl for locale-aware money formatting.
- AdMob remains responsible for ad inventory/targeting; the app does not hard-code an ad language by country.
- For production, add native Android per-app language resources and complete translations for every string before Play release.
